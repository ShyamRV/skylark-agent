"use client";

import { FormEvent, useCallback, useEffect, useMemo, useState } from "react";
import type { QueryPlan } from "@/agent/queryPlan";
import { CockpitNav } from "@/components/cockpit/CockpitNav";
import { MetricCard } from "@/components/cockpit/MetricCard";
import {
  QuickActions,
  type QuickAction,
} from "@/components/cockpit/QuickActions";
import type {
  DashboardData,
  Message,
  ViewName,
} from "@/components/cockpit/types";
import type { WorkflowName } from "@/domain/workflows";

function downloadMarkdown(message: Message) {
  const results = message.results ?? (message.result ? [message.result] : []);
  const markdown = [
    `# ${message.type === "workflow" ? "Founder brief" : "Skylark analysis"}`,
    "",
    message.text,
    "",
    ...results.flatMap((result) => [
      `## ${result.title}`,
      `${result.value ?? "Split by currency"} ${result.unit}`,
      "",
      result.definition,
      "",
      `Data as of: ${result.fetchedAt}`,
      result.warnings.length ? `Caveats: ${result.warnings.join(" ")}` : "",
      "",
    ]),
  ].join("\n");
  const link = document.createElement("a");
  link.href = URL.createObjectURL(new Blob([markdown], { type: "text/markdown" }));
  link.download = `skylark-${new Date().toISOString().slice(0, 10)}.md`;
  link.click();
  URL.revokeObjectURL(link.href);
}

export default function Home() {
  const [view, setView] = useState<ViewName>("overview");
  const [messages, setMessages] = useState<Message[]>([]);
  const [question, setQuestion] = useState("");
  const [accessCode, setAccessCode] = useState("");
  const [loading, setLoading] = useState(false);
  const [dashboard, setDashboard] = useState<DashboardData | null>(null);
  const [dashboardLoading, setDashboardLoading] = useState(true);

  const recent = useMemo(() => {
    const results = messages
      .flatMap((message) => message.results ?? (message.result ? [message.result] : []))
      .reverse();
    return [...new Map(results.map((result) => [result.metric, result])).values()];
  }, [messages]);

  const loadDashboard = useCallback(async () => {
    setDashboardLoading(true);
    try {
      const response = await fetch("/api/dashboard", {
        headers: accessCode ? { "x-demo-access-code": accessCode } : {},
        cache: "no-store",
      });
      setDashboard(await response.json());
    } catch {
      setDashboard({ connected: false, message: "The dashboard service could not be reached." });
    } finally {
      setDashboardLoading(false);
    }
  }, [accessCode]);

  useEffect(() => {
    let active = true;
    fetch("/api/dashboard", {
      headers: accessCode ? { "x-demo-access-code": accessCode } : {},
      cache: "no-store",
    })
      .then((response) => response.json())
      .then((body) => {
        if (active) setDashboard(body);
      })
      .catch(() => {
        if (active)
          setDashboard({
            connected: false,
            message: "The dashboard service could not be reached.",
          });
      })
      .finally(() => {
        if (active) setDashboardLoading(false);
      });
    return () => {
      active = false;
    };
  }, [accessCode]);

  async function ask(
    value: string,
    options: { workflow?: WorkflowName; plan?: QueryPlan; sector?: string } = {},
  ) {
    const trimmed = value.trim();
    if (!trimmed || loading) return;
    const userId = Date.now();
    setMessages((current) => [
      ...current,
      { id: userId, role: "user", text: trimmed, question: trimmed },
    ]);
    setQuestion("");
    setLoading(true);
    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          question: trimmed,
          accessCode: accessCode || undefined,
          action: options.workflow,
          sector: options.sector,
          plan: options.plan,
        }),
      });
      const body = await response.json();
      setMessages((current) => [
        ...current,
        {
          id: userId + 1,
          role: "assistant",
          type: body.type,
          workflow: body.workflow,
          text: body.answer ?? body.message ?? "I could not answer that question.",
          result: body.result,
          results: body.results,
          plan: body.plan,
          plans: body.plans,
          question: trimmed,
          error: !response.ok || body.type === "error",
        },
      ]);
      if (response.ok) void loadDashboard();
    } catch {
      setMessages((current) => [
        ...current,
        {
          id: userId + 1,
          role: "assistant",
          type: "error",
          text: "The service could not be reached. Please try again.",
          question: trimmed,
          error: true,
        },
      ]);
    } finally {
      setLoading(false);
    }
  }

  function runAction(action: QuickAction) {
    if (action.workflow === "leadership_update") setView("leadership");
    else setView("ask");
    void ask(action.question, { workflow: action.workflow });
  }

  function submit(event: FormEvent) {
    event.preventDefault();
    void ask(question);
  }

  async function copyAnswer(message: Message) {
    await navigator.clipboard.writeText(message.text);
  }

  const leadershipMessages = messages.filter(
    (message) =>
      message.type === "workflow" && message.workflow === "leadership_update",
  );

  return (
    <main>
      <header className="topbar">
        <div className="brand">
          <span className="brand-mark">SK</span>
          <div><b>Skylark</b><small>Business intelligence</small></div>
        </div>
        <div className="header-actions">
          <button className="refresh" onClick={() => void loadDashboard()} disabled={dashboardLoading}>
            {dashboardLoading ? "Checking…" : "Refresh"}
          </button>
          <div className={`live ${dashboard?.connected ? "connected" : "disconnected"}`}>
            <span /> {dashboard?.connected ? "monday.com connected" : "Source needs attention"}
          </div>
          <button className="profile" onClick={() => setView("leadership")} aria-label="Open leadership view">FD</button>
        </div>
      </header>

      <div className="shell">
        <CockpitNav
          view={view}
          onView={setView}
          recent={recent}
          accessCode={accessCode}
          onAccessCode={setAccessCode}
          onNewChat={() => { setMessages([]); setView("ask"); }}
        />

        <section className="conversation">
          {view === "overview" && (
            <div className="overview-page">
              <div className="page-heading">
                <div><span className="eyebrow">Live overview</span><h1>Good decisions start here.</h1></div>
                <p>One trusted view of sales pipeline, delivery execution, and source-data quality.</p>
              </div>
              {!dashboard?.connected && !dashboardLoading && (
                <div className="source-alert">
                  <div><b>Connect your monday boards</b><span>{dashboard?.message}</span></div>
                  <button onClick={() => void loadDashboard()}>Try again</button>
                </div>
              )}
              <div className="kpi-grid">
                {dashboardLoading
                  ? Array.from({ length: 6 }).map((_, index) => <div className="kpi-skeleton" key={index} />)
                  : dashboard?.metrics?.map((result) => (
                      <MetricCard result={result} compact key={result.metric} />
                    ))}
              </div>
              {dashboard?.recordCounts && (
                <div className="data-strip">
                  <div><small>DEALS READ</small><b>{dashboard.recordCounts.deals}</b></div>
                  <div><small>WORK ORDERS READ</small><b>{dashboard.recordCounts.workOrders}</b></div>
                  <div><small>FRESHNESS</small><b>{dashboard.fetchedAt ? new Date(dashboard.fetchedAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) : "—"}</b></div>
                  <div><small>MODE</small><b>Read-only</b></div>
                </div>
              )}
              <QuickActions onAction={runAction} />
            </div>
          )}

          {view === "ask" && (
            <>
              {messages.length === 0 ? (
                <div className="ask-empty">
                  <div className="hero-copy">
                    <span className="eyebrow">Ask Skylark</span>
                    <h1>Your business,<br />in one question.</h1>
                    <p>Ask about pipeline, sectors, revenue, work orders, owners, dates, or data quality.</p>
                  </div>
                  <QuickActions onAction={runAction} compact />
                </div>
              ) : (
                <div className="messages" aria-live="polite">
                  {messages.map((message) => (
                    <article className={`message ${message.role} ${message.error ? "error" : ""}`} key={message.id}>
                      <span className="avatar">{message.role === "user" ? "You" : "S"}</span>
                      <div className="message-content">
                        <p className="message-label">{message.role === "user" ? "You" : "Skylark intelligence"}</p>
                        <p className="answer">{message.text}</p>
                        {message.result && (
                          <MetricCard
                            result={message.result}
                            plan={message.plan}
                            onRerun={(plan) => void ask(`Refresh ${message.result!.title}`, { plan })}
                          />
                        )}
                        {message.results?.map((result, index) => (
                          <MetricCard
                            key={`${message.id}-${result.metric}`}
                            result={result}
                            plan={message.plans?.[index]}
                            onRerun={(plan) => void ask(`Refresh ${result.title}`, { plan })}
                          />
                        ))}
                        {message.role === "assistant" && (
                          <div className="message-actions">
                            <button onClick={() => void copyAnswer(message)}>Copy answer</button>
                            {(message.result || message.results) && <button onClick={() => downloadMarkdown(message)}>Download .md</button>}
                            {message.error && message.question && <button onClick={() => void ask(message.question!)}>Retry</button>}
                          </div>
                        )}
                      </div>
                    </article>
                  ))}
                  {loading && (
                    <article className="message assistant">
                      <span className="avatar">S</span>
                      <div className="thinking"><i /><i /><i /><span>Reading both boards and checking the numbers</span></div>
                    </article>
                  )}
                </div>
              )}
              <form className="composer" onSubmit={submit}>
                <textarea
                  value={question}
                  onChange={(event) => setQuestion(event.target.value)}
                  onKeyDown={(event) => {
                    if (event.key === "Enter" && !event.shiftKey) {
                      event.preventDefault();
                      void ask(question);
                    }
                  }}
                  placeholder="Ask about pipeline, sectors, work orders or revenue…"
                  rows={2}
                />
                <button type="submit" disabled={!question.trim() || loading} aria-label="Send question">↑</button>
                <small>Answers include definitions, freshness and data-quality caveats.</small>
              </form>
            </>
          )}

          {view === "leadership" && (
            <div className="leadership-page">
              <div className="leadership-hero">
                <div><span className="eyebrow">Leadership workspace</span><h1>Turn live data into the next update.</h1><p>Generate a concise, copy-ready brief using verified pipeline, win-rate, delivery and quality metrics.</p></div>
                <button disabled={loading} onClick={() => void ask("Prepare a leadership update", { workflow: "leadership_update" })}>
                  {loading ? "Preparing…" : "Prepare update"} <span>↗</span>
                </button>
              </div>
              {leadershipMessages.length ? (
                leadershipMessages.slice().reverse().map((message) => (
                  <article className="leadership-brief" key={message.id}>
                    <div className="brief-header"><span>Generated brief</span><div><button onClick={() => void copyAnswer(message)}>Copy</button><button onClick={() => downloadMarkdown(message)}>Download .md</button></div></div>
                    <p>{message.text}</p>
                    <div className="brief-metrics">
                      {message.results?.map((result) => <MetricCard result={result} compact key={result.metric} />)}
                    </div>
                  </article>
                ))
              ) : (
                <div className="leadership-empty"><b>No brief generated in this session</b><span>Use the button above to prepare one from current monday.com data.</span></div>
              )}
            </div>
          )}
        </section>
      </div>

      <nav className="mobile-nav">
        {(["overview", "ask", "leadership"] as ViewName[]).map((item) => (
          <button className={view === item ? "active" : ""} key={item} onClick={() => setView(item)}>
            {item === "ask" ? "Ask" : item[0].toUpperCase() + item.slice(1)}
          </button>
        ))}
      </nav>
    </main>
  );
}
