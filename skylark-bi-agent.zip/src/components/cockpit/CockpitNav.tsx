"use client";

import { displayValue } from "./MetricCard";
import type { Result, ViewName } from "./types";

const views: { id: ViewName; label: string; hint: string }[] = [
  { id: "overview", label: "Overview", hint: "Live health" },
  { id: "ask", label: "Ask Skylark", hint: "Explore" },
  { id: "leadership", label: "Leadership", hint: "Prepare update" },
];

export function CockpitNav({
  view,
  onView,
  recent,
  accessCode,
  onAccessCode,
  onNewChat,
}: {
  view: ViewName;
  onView: (view: ViewName) => void;
  recent: Result[];
  accessCode: string;
  onAccessCode: (value: string) => void;
  onNewChat: () => void;
}) {
  return (
    <aside>
      <div>
        <span className="eyebrow">Workspace</span>
        <h2>Founder cockpit</h2>
        <p>Verified answers across live Deals and Work Orders.</p>
      </div>
      <nav className="view-nav">
        <span className="nav-title">Navigate</span>
        {views.map((item) => (
          <button
            className={view === item.id ? "active" : ""}
            key={item.id}
            onClick={() => onView(item.id)}
          >
            <span><b>{item.label}</b><small>{item.hint}</small></span>
            <i>↗</i>
          </button>
        ))}
      </nav>
      {recent.length > 0 && (
        <section className="recent-kpis">
          <span className="nav-title">Recent KPIs · this session</span>
          {recent.slice(0, 3).map((result) => (
            <div key={result.metric}>
              <span>{result.title}</span>
              <b>{displayValue(result.value, result.unit, result.currency)}</b>
            </div>
          ))}
        </section>
      )}
      <div className="nav-footer">
        <button className="new-chat" onClick={onNewChat}>＋ New conversation</button>
        <label className="access">
          Demo access code <span>optional</span>
          <input
            type="password"
            value={accessCode}
            onChange={(event) => onAccessCode(event.target.value)}
            placeholder="Only if provided"
          />
        </label>
      </div>
    </aside>
  );
}
