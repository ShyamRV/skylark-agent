import "server-only";
import {
  createAsiClient,
  getAsiModel,
  hasAsiApiKey,
} from "@/lib/asi/client";
import {
  metricNames,
  queryPlanSchema,
  type PlanningResult,
} from "./queryPlan";
import { fallbackPlan } from "./fallbackPlanner";

const SYSTEM_PROMPT = `You plan founder-facing BI questions against a fixed metric catalog.
Return only the requested JSON. Never perform arithmetic.
Metrics: ${metricNames.join(", ")}.
Filter fields: sector, stage, status, owner. Group fields additionally include currency.
Use this_quarter when the user says this quarter. Use all_time if no period is given.
Pipeline means open pipeline_value. For "how is pipeline looking", group by stage.
Questions about data quality, missing data, bad records, or quality issues map to
data_quality_summary; this metric is an aggregate and is supported.
Questions about aging buckets map to deal_aging_buckets, stuck or past-close deals
map to stuck_pipeline, and due soon means due_soon_work_orders.
If a question is materially ambiguous, return clarification. If it asks for unsupported
forecasting, prediction, arbitrary records, or unrelated knowledge, return unsupported.`;

const responseSchema = {
  name: "bi_query_plan",
  strict: true,
  schema: {
    type: "object",
    additionalProperties: false,
    required: ["kind", "plan", "question", "reason"],
    properties: {
      kind: { type: "string", enum: ["plan", "clarification", "unsupported"] },
      plan: {
        anyOf: [
          {
            type: "object",
            additionalProperties: false,
            required: ["metric", "filters", "groupBy", "timeRange", "limit"],
            properties: {
              metric: {
                type: "string",
                enum: metricNames,
              },
              filters: {
                type: "array",
                maxItems: 8,
                items: {
                  type: "object",
                  additionalProperties: false,
                  required: ["field", "operator", "value"],
                  properties: {
                    field: { type: "string", enum: ["sector", "stage", "status", "owner"] },
                    operator: { type: "string", enum: ["equals", "contains", "in"] },
                    value: {
                      anyOf: [
                        { type: "string" },
                        { type: "array", items: { type: "string" }, maxItems: 20 },
                      ],
                    },
                  },
                },
              },
              groupBy: {
                type: ["string", "null"],
                enum: ["sector", "stage", "status", "owner", "currency", null],
              },
              timeRange: {
                type: "object",
                additionalProperties: false,
                required: ["preset"],
                properties: {
                  preset: {
                    type: "string",
                    enum: ["all_time", "this_quarter", "last_quarter", "this_year"],
                  },
                },
              },
              limit: { type: "integer", minimum: 1, maximum: 20 },
            },
          },
          { type: "null" },
        ],
      },
      question: { type: ["string", "null"] },
      reason: { type: ["string", "null"] },
    },
  },
} as const;

export async function planQuestion(question: string): Promise<PlanningResult> {
  if (!hasAsiApiKey()) return fallbackPlan(question);
  if (
    /data quality|quality issues?|aging buckets?|pipeline aging|stuck (pipeline|deals?)|past[- ]close|due soon|next 14 days|completion rate|average deal (size|value)|lost (deal )?(value|revenue)|work order value|delivery value/i.test(
      question,
    )
  )
    return fallbackPlan(question);

  const asi = createAsiClient();
  const response = await asi.chat.completions.create({
    model: getAsiModel(),
    messages: [
      { role: "system", content: SYSTEM_PROMPT },
      { role: "user", content: question },
    ],
    temperature: 0,
    max_tokens: 700,
    response_format: { type: "json_schema", json_schema: responseSchema },
  });
  const content = response.choices[0]?.message.content;
  if (!content) throw new Error("The planning model returned an empty response.");
  const parsed = JSON.parse(content) as {
    kind: string;
    plan: unknown;
    question: string | null;
    reason: string | null;
  };
  if (parsed.kind === "clarification")
    return {
      kind: "clarification",
      question: parsed.question ?? "Which metric and period should I use?",
    };
  if (parsed.kind === "unsupported")
    return {
      kind: "unsupported",
      reason: parsed.reason ?? "That question is outside the supported metric catalog.",
    };
  return { kind: "plan", plan: queryPlanSchema.parse(parsed.plan) };
}
