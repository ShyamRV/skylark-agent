import "server-only";
import type { MetricResult } from "@/domain/types";
import {
  createAsiClient,
  getAsiModel,
  hasAsiApiKey,
} from "@/lib/asi/client";

function formatValue(
  value: number | null,
  unit: MetricResult["unit"],
  currency?: string,
) {
  if (value === null) return "not safely aggregatable";
  if (unit === "currency")
    return new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: currency ?? "INR",
      maximumFractionDigits: 0,
    }).format(value);
  if (unit === "percent") return `${value.toFixed(1)}%`;
  if (unit === "days") return `${value.toFixed(1)} days`;
  return new Intl.NumberFormat("en-IN").format(value);
}

export function deterministicNarrative(result: MetricResult) {
  const headline = `${result.title}: ${formatValue(
    result.value,
    result.unit,
    result.currency,
  )}.`;
  const top = result.breakdown
    .slice(0, 3)
    .map(
      (entry) =>
        `${entry.label}: ${formatValue(entry.value, entry.unit, entry.currency)}`,
    )
    .join("; ");
  const caveat = result.warnings[0] ? ` Caveat: ${result.warnings[0]}` : "";
  return `${headline}${top ? ` Leading breakdown — ${top}.` : ""}${caveat}`;
}

export async function narrateResult(
  question: string,
  result: MetricResult,
): Promise<string> {
  if (!hasAsiApiKey()) return deterministicNarrative(result);
  const asi = createAsiClient();
  const response = await asi.chat.completions.create({
    model: getAsiModel(),
    messages: [
      {
        role: "system",
        content:
          "Write a concise founder-ready answer using only the supplied computed result. Do not recalculate, infer causes, speculate about completeness, invent trends, or add caveats not present in the warnings. Lead with the answer, mention the strongest breakdown signal, and state only supplied material caveats. Maximum 100 words.",
      },
      {
        role: "user",
        content: JSON.stringify({ question, computedResult: result }),
      },
    ],
    temperature: 0.2,
    max_tokens: 250,
  });
  return response.choices[0]?.message.content ?? deterministicNarrative(result);
}

export async function narrateLeadershipUpdate(
  results: MetricResult[],
  heading = "Leadership update",
) {
  const facts = results.map((result) => ({
    title: result.title,
    value: formatValue(result.value, result.unit, result.currency),
    breakdown: result.breakdown.slice(0, 3),
    warnings: result.warnings.slice(0, 2),
  }));
  if (!hasAsiApiKey()) {
    return [
      heading,
      ...results.map((result) => `• ${deterministicNarrative(result)}`),
      "Follow-up: resolve the data-quality caveats above before the next review.",
    ].join("\n");
  }
  const asi = createAsiClient();
  const response = await asi.chat.completions.create({
    model: getAsiModel(),
    messages: [
      {
        role: "system",
        content:
          "Create a copyable founder brief from verified facts only. Use short sections for highlights, risks, data caveats, and follow-ups. Do not infer causes, speculate about completeness, invent trends, or add facts not supplied. Maximum 180 words.",
      },
      { role: "user", content: JSON.stringify({ heading, facts }) },
    ],
    temperature: 0.2,
    max_tokens: 450,
  });
  return response.choices[0]?.message.content ?? "Leadership update unavailable.";
}
