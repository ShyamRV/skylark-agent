import "server-only";
import { getBoardConfig } from "@/config/boards";
import { normalizeBoards } from "@/domain/normalize";
import type { DataSnapshot, DataWarning, MondayItem } from "@/domain/types";
import { mondayQuery } from "./client";

const FIRST_PAGE = `
  query BoardItems($boardId: ID!, $limit: Int!) {
    boards(ids: [$boardId]) {
      items_page(limit: $limit) {
        cursor
        items {
          id
          name
          created_at
          column_values { id type text value }
        }
      }
    }
  }
`;

const NEXT_PAGE = `
  query MoreBoardItems($cursor: String!, $limit: Int!) {
    next_items_page(cursor: $cursor, limit: $limit) {
      cursor
      items {
        id
        name
        created_at
        column_values { id type text value }
      }
    }
  }
`;

type Page = { cursor: string | null; items: MondayItem[] };

async function loadBoard(
  boardId: string,
): Promise<{ items: MondayItem[]; warnings: DataWarning[] }> {
  const items: MondayItem[] = [];
  const warnings: DataWarning[] = [];
  const first = await mondayQuery<{ boards: { items_page: Page }[] }>(
    FIRST_PAGE,
    { boardId, limit: 250 },
  );
  const page = first.data.boards[0]?.items_page;
  if (!page) throw new Error(`Board ${boardId} was not found or is not accessible.`);
  items.push(...page.items);
  if (first.errors.length) {
    warnings.push({
      code: "partial_read",
      entity: "snapshot",
      message: first.errors.map((error) => error.message).join("; "),
    });
  }

  let cursor = page.cursor;
  while (cursor) {
    const next = await mondayQuery<{ next_items_page: Page }>(NEXT_PAGE, {
      cursor,
      limit: 250,
    });
    items.push(...next.data.next_items_page.items);
    cursor = next.data.next_items_page.cursor;
    if (next.errors.length) {
      warnings.push({
        code: "partial_read",
        entity: "snapshot",
        message: next.errors.map((error) => error.message).join("; "),
      });
    }
  }

  return { items, warnings };
}

let cached: { expiresAt: number; snapshot: DataSnapshot } | null = null;

export async function loadSnapshot(): Promise<DataSnapshot> {
  if (cached && cached.expiresAt > Date.now()) return cached.snapshot;

  const config = getBoardConfig();
  const [deals, workOrders] = await Promise.all([
    loadBoard(config.dealsBoardId),
    loadBoard(config.workOrdersBoardId),
  ]);
  const snapshot = normalizeBoards(
    deals.items,
    workOrders.items,
    config,
    [...deals.warnings, ...workOrders.warnings],
  );
  cached = { snapshot, expiresAt: Date.now() + 60_000 };
  return snapshot;
}

export function clearSnapshotCache() {
  cached = null;
}
