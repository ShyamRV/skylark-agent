import { NextResponse } from "next/server";
import { z } from "zod";
import { narrateLeadershipUpdate, narrateResult } from "@/agent/narrator";
import { planQuestion } from "@/agent/planner";
import { queryPlanSchema } from "@/agent/queryPlan";
import { runMetric } from "@/domain/metrics";
import {
  workflowFromQuestion,
  workflowNames,
  workflowPlans,
} from "@/domain/workflows";
import { MondayApiError } from "@/lib/monday/client";
import { loadSnapshot } from "@/lib/monday/loadBoards";

export const runtime = "nodejs";
export const maxDuration = 30;

const requestSchema = z.object({
  question: z.string().trim().min(2).max(500),
  accessCode: z.string().max(100).optional(),
  action: z.enum(workflowNames).optional(),
  sector: z.string().trim().min(1).max(100).optional(),
  plan: queryPlanSchema.optional(),
});

const workflowLabels = {
  leadership_update: "Leadership update",
  pipeline_review: "Pipeline review",
  delivery_standup: "Delivery stand-up",
  sector_deep_dive: "Sector deep-dive",
  data_quality_review: "Data quality review",
} as const;

export async function POST(request: Request) {
  try {
    const input = requestSchema.parse(await request.json());
    if (
      process.env.DEMO_ACCESS_CODE &&
      input.accessCode !== process.env.DEMO_ACCESS_CODE
    ) {
      return NextResponse.json(
        { type: "error", message: "The demo access code is incorrect." },
        { status: 401 },
      );
    }

    const snapshot = await loadSnapshot();
    const workflow = input.action ?? workflowFromQuestion(input.question);
    if (workflow) {
      const plans = workflowPlans(workflow, input.sector);
      const results = plans.map((plan) => runMetric(snapshot, plan));
      return NextResponse.json({
        type: "workflow",
        workflow,
        answer: await narrateLeadershipUpdate(
          results,
          workflowLabels[workflow],
        ),
        plans,
        results,
      });
    }

    const planning = input.plan
      ? ({ kind: "plan", plan: input.plan } as const)
      : await planQuestion(input.question);
    if (planning.kind === "clarification")
      return NextResponse.json({
        type: "clarification",
        message: planning.question,
      });
    if (planning.kind === "unsupported")
      return NextResponse.json({
        type: "unsupported",
        message: planning.reason,
      });

    const result = runMetric(snapshot, planning.plan);
    return NextResponse.json({
      type: "answer",
      answer: await narrateResult(input.question, result),
      plan: planning.plan,
      result,
    });
  } catch (error) {
    console.error("Chat request failed", error);
    if (error instanceof z.ZodError)
      return NextResponse.json(
        { type: "error", message: "The request or generated query was invalid." },
        { status: 400 },
      );
    if (error instanceof MondayApiError)
      return NextResponse.json(
        {
          type: "error",
          message: error.retryable
            ? "monday.com is temporarily unavailable. Please retry shortly."
            : error.message,
        },
        { status: error.retryable ? 503 : 502 },
      );
    return NextResponse.json(
      {
        type: "error",
        message:
          error instanceof Error
            ? error.message
            : "An unexpected error occurred.",
      },
      { status: 500 },
    );
  }
}
