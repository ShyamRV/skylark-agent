import { NextResponse } from "next/server";
import { queryPlanSchema } from "@/agent/queryPlan";
import { runMetric } from "@/domain/metrics";
import { MondayApiError } from "@/lib/monday/client";
import { loadSnapshot } from "@/lib/monday/loadBoards";

export const runtime = "nodejs";
export const maxDuration = 30;

export async function GET(request: Request) {
  if (
    process.env.DEMO_ACCESS_CODE &&
    request.headers.get("x-demo-access-code") !== process.env.DEMO_ACCESS_CODE
  ) {
    return NextResponse.json(
      { connected: false, message: "The demo access code is incorrect." },
      { status: 401 },
    );
  }

  try {
    const snapshot = await loadSnapshot();
    const plans = [
      queryPlanSchema.parse({
        metric: "pipeline_value",
        groupBy: "stage",
        timeRange: { preset: "this_quarter" },
      }),
      queryPlanSchema.parse({
        metric: "win_rate",
        timeRange: { preset: "this_quarter" },
      }),
      queryPlanSchema.parse({ metric: "stuck_pipeline", groupBy: "owner" }),
      queryPlanSchema.parse({ metric: "overdue_work_orders", groupBy: "owner" }),
      queryPlanSchema.parse({
        metric: "completion_rate",
        timeRange: { preset: "this_quarter" },
      }),
      queryPlanSchema.parse({ metric: "data_quality_summary" }),
    ];
    const warningCounts = Object.fromEntries(
      snapshot.warnings.reduce((counts, warning) => {
        counts.set(warning.code, (counts.get(warning.code) ?? 0) + 1);
        return counts;
      }, new Map<string, number>()),
    );

    return NextResponse.json({
      connected: true,
      fetchedAt: snapshot.fetchedAt,
      recordCounts: {
        deals: snapshot.deals.length,
        workOrders: snapshot.workOrders.length,
      },
      warningCounts,
      metrics: plans.map((plan) => runMetric(snapshot, plan)),
    });
  } catch (error) {
    console.error("Dashboard request failed", error);
    const retryable = error instanceof MondayApiError && error.retryable;
    return NextResponse.json(
      {
        connected: false,
        message: retryable
          ? "monday.com is temporarily unavailable."
          : error instanceof Error
            ? error.message
            : "Dashboard data could not be loaded.",
      },
      { status: retryable ? 503 : 502 },
    );
  }
}
